import ReportRepository from "../repository/ReportRepository";

class ReportGenerator {
    reportRepository: ReportRepository = new ReportRepository();
    reportType: String = '';

    generateReport() {
        const report = this.reportRepository.getReport();
        if (this.reportType === 'Sales') {
            return report.map(({id, date, pieces, amount, client}) => ({ id, date, pieces, amount, client }))
        } else if (this.reportType === 'Services') {
            return report.map(({id, date, pieces, location, type, technician}) => ({id, date, pieces, location, type, technician}))
        } else if (this.reportType === 'Internal' ) {
            return [];
        }
    }
}

export default ReportGenerator;