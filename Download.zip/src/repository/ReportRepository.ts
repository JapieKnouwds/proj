class ReportRepository {
    getReport() {
        return [{
            "id": 1,
            "date": "2021-07-14T20:15:41Z",
            "pieces": 332,
            "amount": "$87705.24",
            "location": "Na Yong",
            "type": "Preventive Maintenance",
            "technician": "Bridgette Sebborn",
            "client": "Mann-Bayer"
          }, {
            "id": 2,
            "date": "2021-08-15T01:24:23Z",
            "pieces": 342,
            "amount": "$38354.21",
            "location": "Bairro dos Marinheiros",
            "type": "Repair",
            "technician": "Niels Groves",
            "client": "Block-Ryan"
          }, {
            "id": 3,
            "date": "2021-05-17T17:04:17Z",
            "pieces": 211,
            "amount": "$180944.41",
            "location": "Gambiran",
            "type": "Preventive Maintenance",
            "technician": "Scot Ivanchin",
            "client": "Bahringer Inc"
          }, {
            "id": 4,
            "date": "2021-07-20T09:21:52Z",
            "pieces": 374,
            "amount": "$79203.62",
            "location": "Sannikovo",
            "type": "Preventive Maintenance",
            "technician": "Charley McGauhy",
            "client": "VonRueden and Sons"
          }, {
            "id": 5,
            "date": "2021-04-04T19:49:51Z",
            "pieces": 357,
            "amount": "$133429.94",
            "location": "Chimen",
            "type": "Preventive Maintenance",
            "technician": "Hyacinthie Belitz",
            "client": "Rutherford-Abbott"
          }, {
            "id": 6,
            "date": "2020-10-07T02:01:29Z",
            "pieces": 4,
            "amount": "$11658.24",
            "location": "Boulder",
            "type": "Repair",
            "technician": "Goddard Tivers",
            "client": "Ondricka-Wintheiser"
          }, {
            "id": 7,
            "date": "2021-04-04T07:11:18Z",
            "pieces": 124,
            "amount": "$203521.06",
            "location": "Jabon",
            "type": "Preventive Maintenance",
            "technician": "Sandra Summerhayes",
            "client": "Gutkowski-Wiegand"
          }, {
            "id": 8,
            "date": "2021-04-07T14:04:41Z",
            "pieces": 199,
            "amount": "$40829.77",
            "location": "El Potrero",
            "type": "Preventive Maintenance",
            "technician": "Legra Drewet",
            "client": "Brekke, Fritsch and Labadie"
          }, {
            "id": 9,
            "date": "2021-07-01T18:33:50Z",
            "pieces": 414,
            "amount": "$14948.05",
            "location": "Arrah",
            "type": "Repair",
            "technician": "Nissy Kerfoot",
            "client": "Streich-Pagac"
          }, {
            "id": 10,
            "date": "2021-04-20T11:04:40Z",
            "pieces": 238,
            "amount": "$96378.76",
            "location": "Huanggang",
            "type": "Preventive Maintenance",
            "technician": "Maighdiln Dorey",
            "client": "Stark-Johnson"
          }, {
            "id": 11,
            "date": "2021-06-13T20:58:19Z",
            "pieces": 375,
            "amount": "$169695.50",
            "location": "Rasshevatskaya",
            "type": "Preventive Maintenance",
            "technician": "Allyce Symson",
            "client": "Hodkiewicz Group"
          }, {
            "id": 12,
            "date": "2020-12-04T14:48:52Z",
            "pieces": 390,
            "amount": "$169226.57",
            "location": "Zhonghe",
            "type": "Repair",
            "technician": "Karol Beningfield",
            "client": "Rohan-Jerde"
          }, {
            "id": 13,
            "date": "2020-09-14T03:56:01Z",
            "pieces": 316,
            "amount": "$147898.65",
            "location": "Arroyo Seco",
            "type": "Other",
            "technician": "Pamela Spurier",
            "client": "Lang, Quitzon and Feest"
          }, {
            "id": 14,
            "date": "2020-11-22T04:52:22Z",
            "pieces": 389,
            "amount": "$6823.74",
            "location": "Toufang",
            "type": "Preventive Maintenance",
            "technician": "Sybyl Draye",
            "client": "Halvorson and Sons"
          }, {
            "id": 15,
            "date": "2021-03-05T20:48:13Z",
            "pieces": 48,
            "amount": "$32842.38",
            "location": "Tando Muhammad Khān",
            "type": "Preventive Maintenance",
            "technician": "Allister Ivannikov",
            "client": "Kohler Group"
          }, {
            "id": 16,
            "date": "2021-04-10T21:14:03Z",
            "pieces": 53,
            "amount": "$62904.95",
            "location": "Centenary",
            "type": "Preventive Maintenance",
            "technician": "Barron Ketley",
            "client": "Nader Group"
          }, {
            "id": 17,
            "date": "2020-12-27T06:04:14Z",
            "pieces": 165,
            "amount": "$176017.99",
            "location": "Veltruby",
            "type": "Preventive Maintenance",
            "technician": "Wilfrid Puvia",
            "client": "Tillman-Cremin"
          }, {
            "id": 18,
            "date": "2021-06-18T01:14:03Z",
            "pieces": 80,
            "amount": "$108018.95",
            "location": "Winburg",
            "type": "Preventive Maintenance",
            "technician": "Casey Windridge",
            "client": "Reinger-Flatley"
          }, {
            "id": 19,
            "date": "2021-08-04T15:45:09Z",
            "pieces": 26,
            "amount": "$93926.21",
            "location": "Batan",
            "type": "Preventive Maintenance",
            "technician": "Ryon Delgado",
            "client": "Spencer-Zboncak"
          }, {
            "id": 20,
            "date": "2020-10-28T05:12:14Z",
            "pieces": 125,
            "amount": "$256218.93",
            "location": "Tân Sơn",
            "type": "Other",
            "technician": "Dyna Hundall",
            "client": "Johnston, Kuhlman and Schmeler"
          }, {
            "id": 21,
            "date": "2021-08-04T23:05:38Z",
            "pieces": 337,
            "amount": "$285991.40",
            "location": "Andongrejo",
            "type": "Other",
            "technician": "Lorne Bertenshaw",
            "client": "Beier Group"
          }, {
            "id": 22,
            "date": "2021-01-22T00:13:55Z",
            "pieces": 166,
            "amount": "$94174.32",
            "location": "Tsybli",
            "type": "Preventive Maintenance",
            "technician": "Jeannie Binns",
            "client": "Murray Inc"
          }, {
            "id": 23,
            "date": "2020-12-21T00:12:24Z",
            "pieces": 367,
            "amount": "$171833.46",
            "location": "Rączna",
            "type": "Preventive Maintenance",
            "technician": "Zorine Baack",
            "client": "Waters, Murray and Welch"
          }, {
            "id": 24,
            "date": "2021-03-13T08:16:13Z",
            "pieces": 340,
            "amount": "$266224.67",
            "location": "Lukou",
            "type": "Preventive Maintenance",
            "technician": "Abbey Heinl",
            "client": "Kiehn-Dicki"
          }, {
            "id": 25,
            "date": "2020-12-20T22:43:12Z",
            "pieces": 210,
            "amount": "$33823.32",
            "location": "Pitangueiras",
            "type": "Preventive Maintenance",
            "technician": "Yolanthe Acom",
            "client": "Harber-Fay"
          }]
    }
}

export default ReportRepository;