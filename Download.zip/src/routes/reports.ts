import { Router } from "express";
import ReportGenerator from "../service/ReportGenerator";

const router = Router();

router.get('/', (req, res) => {
    const type = req.query.type as String;
    const reportGenerator = new ReportGenerator();
    reportGenerator.reportType = type;

    res.json({reports: reportGenerator.generateReport()});
})

export default router;