async function updateReportTable() {
    const type = document.getElementById('type-select').value;
    fetch(`/reports?${new URLSearchParams({ type })}`)
        .then(response => response.json())
        .then(result => createReportTable(result.reports));
}

function createReportTable(reports) {
    const table = document.createElement('table');
    const header = createReportTableHeader(reports);
    const tableBody = createReportTableBody(reports);

    table.appendChild(header);
    table.appendChild(tableBody);

    const container = document.getElementById('report-container');
    if (container.firstChild) {
        container.firstChild.replaceWith(table);
    } else {
        container.appendChild(table);
    }
}

function createReportTableHeader(reports) {
    const header = document.createElement('thead');
    const headerRow = document.createElement('tr');

    const columnNames = Object.keys(reports[0]);
    columnNames.forEach(name => {
        const column = document.createElement('th');
        column.appendChild(document.createTextNode(name));
        headerRow.appendChild(column);
    });

    header.appendChild(headerRow);
    return header;
}

function createReportTableBody(reports) {
    const body = document.createElement('tbody');
    const columnNames = Object.keys(reports[0])
    reports.forEach(report => {
        const row = document.createElement('tr');
        columnNames.forEach(name => {
            const column = document.createElement('td');
            column.appendChild(document.createTextNode(report[name] || ''));
            row.appendChild(column);
        });
        body.appendChild(row);
    });

    return body;
}