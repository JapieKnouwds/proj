# Interview Skeleton Project (Report Viewer)
This is a bare-bones web app for viewing service reports for a fictitious company.

## Requirements
* Node

## Setup
1. Install dependencies with `npm i`
2. Run dev server with `npm run dev`
3. Open app in browser at http://localhost:3000/